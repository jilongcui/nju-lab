# 提交前自检清单

- [ ] SKILL.md frontmatter 完整（name / description），description 写清了"何时使用该 Skill"
- [ ] 能力边界如实填写，含"不处理"的情况
- [ ] 建模口径全部实现，与 SKILL.md 描述一致
- [ ] 5 个测试用例全部本地跑过，通过率记录在实测档案
- [ ] 踩坑记录（pitfalls）至少 1 条且**每条写成一行**（平台按行计数），是真实自测中遇到的
- [ ] 输出 JSON 的键名与口径完全符合 problem/task.md（键名写错 = 判不通过）
- [ ] 没有为了通过测试而在脚本里写死 expected 的值（复验换 case 就会露馅）
- [ ] 打包 ZIP 内不嵌套多余目录（解压即得 ml-basics/）
