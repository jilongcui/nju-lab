import Schema from "@deepseek-ai/schemastery";
import { Context, Volatile } from "@deepseek-ai/cordis";

//#region src/host/config.d.ts
/**
* 平台下发的评估条件（server 侧字段，见 REQ-2026-09-21 §0.2）。
*
* 注意映射关系（REQ §1.3）：
*  - `model` / `reasoningEffort` 可以用 `agent/request` waterfall 钉死
*  - `tools` 白名单 **不能** 用 waterfall，必须用 `ctx.tools.restrict({ allow })`
*  - `timeoutSeconds` DSH 侧无法钉，仅作展示
*/
/**
 * 平台下发的评估条件（server 侧字段，见 REQ-2026-09-21 §0.2）。
 *
 * 注意映射关系（REQ §1.3）：
 *  - `model` / `reasoningEffort` 可以用 `agent/request` waterfall 钉死
 *  - `tools` 白名单 **不能** 用 waterfall，必须用 `ctx.tools.restrict({ allow })`
 *  - `timeoutSeconds` DSH 侧无法钉，仅作展示
 */
interface EvalConfig {
  model?: string;
  reasoningEffort?: string;
  /**
   * 是否启用步骤机（平台下发）。最后两章是开放实验 → `false`：
   * 客户端不注册 `nju_lab_step`，引导换成"只答疑不代做"。
   */
  guided?: boolean;
  /** 工具白名单（平台下发，如 ["shell"]）；由 ctx.tools.restrict 生效 */
  tools?: string[];
  /** 平台侧的运行超时；DSH 侧无法强制，仅展示 */
  timeoutSeconds?: number;
}
/**
 * 插件配置（schema 解析后的**输出**形态）。
 *
 * DSH 0.1.7 起，设置页只投影 Config schema 里标了 `.volatile()` 的字段
 * （见 `@deepseek-ai/dsh-settings` 的 `volatileForm`）。volatile 字段在运行时是
 * `Volatile<T>` 稳定**引用**：用户在设置页改动后引用内的值即时更新，所以读值
 * 必须 `.get()`，不能当普通值用。据此分两类：
 *  - 要出现在设置页里的字段（serverUrl / token）→ `.volatile()`
 *  - 其余字段（evalConfig / workspaceDir）保持普通，不进设置页
 *
 * 普通对象会被 DSH 拒绝，必须用 schemastery Schema 导出同名 `Config`。
 */
interface Config {
  /** 平台服务基址，例如 https://lab.example.edu/api */
  serverUrl: Volatile<string>;
  /** 个人 token（仅本地调试用；正式版从 credentials 服务取）。 */
  token: Volatile<string | undefined>;
  /** 默认评估条件；claim 下发的值优先，重启后也会从工作区恢复上次 claim 的条件。 */
  evalConfig?: EvalConfig;
  /** 领取物落盘与打包产物的根目录（默认进程工作目录）。 */
  workspaceDir?: string;
  /**
   * 学员模式（默认开）：逐步引导，每步结束要学生明确说"下一步"才继续，
   * 最后一步按模板自动生成 `report.md`。熟练学生可在设置里关掉切回自由模式。
   */
  guidedMode: Volatile<boolean>;
  /** 完全不注入任何实验提示（连"只答疑"那段也不要）—— 想自己安静做实验时用 */
  guidanceOff?: Volatile<boolean>;
}
declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
  serverUrl: Schema<string, string, "volatile-defined">;
  token: Schema<string, string, "volatile">;
  evalConfig: Schema<any, any, "plain">;
  workspaceDir: Schema<string, string, "plain">;
  guidedMode: Schema<boolean, boolean, "volatile-defined">;
  guidanceOff: Schema<boolean, boolean, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  serverUrl: Schema<string, string, "volatile-defined">;
  token: Schema<string, string, "volatile">;
  evalConfig: Schema<any, any, "plain">;
  workspaceDir: Schema<string, string, "plain">;
  guidedMode: Schema<boolean, boolean, "volatile-defined">;
  guidanceOff: Schema<boolean, boolean, "volatile-defined">;
}>>, "plain">; //#endregion
//#region src/host/guide.d.ts

/**
 * 解包 volatile 引用后的普通配置。
 *
 * volatile 字段是 `Volatile<T>` 引用（`.get()` 取当前快照），而 api / panel /
 * actions 这些消费者只想要普通值。集中在这里解包，消费者一律用本类型。
 */
/** 实验类型决定步骤文案与报告表格列。 */
type ExperimentKind = 'classification' | 'regression' | 'dl-classification' | 'dl-regression'
/** 二分类偏召回/精确率（失约预测、缺陷检出） */ | 'detection'
/** 检索类（recall_at_k_*） */ | 'retrieval'
/**
 * 工程实现型：按题目口径写一段确定性代码（四环实现 / 记忆状态机 / 协议报文 / 判定脚本）。
 * 这一类**没有"定基线 → 训练 → 指标"**，交付物是逐字段可比的结构（output.json）。
 */ | 'engineering'
/**
 * 数据库 / 知识库类：建库建表 / 增删改查 / 向量检索 / 图谱多跳。
 * 流程是「摸清数据 → 搭结构与环境 → 增删改查 → 验证查询」，同样**没有基线、训练、指标**。
 */ | 'database'
/**
 * 搭建型：自己写一个**能跑的 agent**（循环 / 工具 / 记忆 / 边界），交付物是一份产出 + 能对话的应用。
 * 与前几种的区别：**没有标准答案、没有 expected.json**，判"事情办成没有"而不是"和答案像不像"。
 * 识别依据：题目包 `manifest.json` 里 `runMode: "script"`（交付物是可执行程序）。
 */ | 'agent' | 'generic';
interface StepDef {
  /** 稳定 id，写进 progress.json，改名会让老进度对不上 */
  id: string;
  title: string;
  /** 这一步要做什么（给模型看的指令，也是给学生看的说明） */
  ask: string;
  /** 这一步至少要有哪些产出，才算做完了（用于提示，不硬拦） */
  need: string;
  /**
   * 这一步由谁动手（2026-10-23 用户口径：教导模式下**学员做，AI 只讲解与检查**）。
   * 只有最后一步"生成报告"由 AI 用工具完成 —— 那本来就是机器活。
   */
  owner: 'student' | 'coach';
}
/** 从 `output.json` 的指标形状推断实验类型（也用于给报告选表格列）。 */
declare function detectKind(output: Record<string, unknown> | null | undefined): ExperimentKind;
/**
 * 从题目包里的**声明**判断实验类型 —— 比猜 `output.json` 可靠：学生刚开工时 `output.json` 还不存在，
 * 而 `problem/manifest.json` 与 `problem/task.md` 在 claim 时就已落到工作区。
 *
 * 认两种写法（出题侧二选一即可，建议都写）：
 *  - `manifest.json` 的 `"flow": "engineering"`；
 *  - `task.md` 里的「流程归属」段落含「工程实现型」。
 *
 * 识别不出来就返回 `null` —— 交给 {@link detectKind} 按产出猜，不要瞎判。
 */
declare function kindFromDeclaration(text: string | null | undefined): ExperimentKind | null;
/**
 * 已落盘的 kind 与工作区声明不一致时**重排步骤**（声明优先）。
 *
 * 为什么需要：老会话的 `progress.json` 是按"猜 output.json"写下的（例如被猜成 classification），
 * 于是面板一直显示"定基线 / 评估 accuracy"，与实际任务打架。声明是出题人写死的，比猜可靠。
 * `records` 与 `mode` 保留（按 stepId 存，不丢数据），`step` 归零让他从第 1 步重新确认。
 */
declare function rebaseKind(state: GuideState, declared: ExperimentKind | null): GuideState;
/**
 * 进来时工作区还没有 `output.json`（→ 只能判成 generic）；等第一份产出出现后**再认一次**类型。
 *
 * 为什么需要：学员模式的步骤在第一次 `status` 时定下来，而"工程实现型"（四环 / 状态机 / 报文 / 判定）
 * 的识别依据是 `output.json` 的键 —— 学生开工那一刻它还不存在。不加这一步，这四个实验会一直套着
 * generic 那套"定基线 → 报指标"的步骤。
 *
 * 只在**还没动过**（第 0 步、没确认、没记录）时才升级，避免把已经走到第 3 步的进度打回第 1 步。
 */
declare function upgradeKind(state: GuideState, output: Record<string, unknown> | null | undefined): GuideState;
declare function stepsFor(kind: ExperimentKind): StepDef[];
/** 学员在实验开始时选的节奏（用户 2026-10-23 口径）。 */
type StudyMode = 'auto' | 'manual';
interface GuideState {
  assignmentId: string;
  kind: ExperimentKind;
  /**
   * 节奏：`manual` = 学员自己动手（默认教导口径）；`auto` = AI 带做、学员做选择与确认；
   * `null` = 还没选 —— 第一次 status 时先用 ask_user 让他选。
   */
  mode: StudyMode | null;
  /** 当前第几步（0-based） */
  step: number;
  /** 各步产出：键是步骤 id，值是模型记录的结构化对象 */
  records: Record<string, Record<string, unknown>>;
  /** 学生已经确认到第几步（含）——`advance` 只能被确认驱动 */
  confirmed: number;
  updatedAt: string;
}
declare function newGuideState(assignmentId: string, kind?: ExperimentKind): GuideState;
/** 进度文件路径：与评估条件钉定文件同一个目录（`nju-lab/<assignmentId>/`）。 */
declare function guidePath(workspaceRoot: string, assignmentId: string): string;
declare function loadGuide(workspaceRoot: string, assignmentId: string): Promise<GuideState | null>;
declare function saveGuide(workspaceRoot: string, state: GuideState): Promise<void>;
/** 记录某一步的产出（浅合并，便于模型分几次补）。 */
declare function recordStep(state: GuideState, stepId: string, patch: Record<string, unknown>): GuideState;
/** 推进到下一步；已在最后一步时不动（返回原状态，由调用方提示"该生成报告了"）。 */
declare function advanceStep(state: GuideState): GuideState;
/** 这一步实际由谁动手：`auto` 模式下 AI 可以代做（学员负责选择/确认）；`report` 永远归 AI。 */

interface StepView {
  title: string;
  /** 已推进过的步骤 */
  done: boolean;
  /** 当前这一步 */
  current: boolean;
  owner: 'student' | 'coach';
}
/** 六步清单（面板与工具返回都用它，保证"看到的是同一份进度"）。 */
declare function stepList(state: GuideState): StepView[];
/** 一行一条的文本清单：`✓` 已完成、`▶` 当前、`○` 未开始。 */
declare function renderStepList(state: GuideState): string;
/** 给模型/学生看的一行摘要。 */
declare function describeStep(state: GuideState): string;

//#endregion
//#region src/host/report.d.ts
interface ReportCase {
  /** 目录名，例如 case01 / run_case01 */
  name: string;
  /** 该 case 的 output.json 内容；读不到时为 null（报告里标"未找到"而不是崩） */
  output: Record<string, unknown> | null;
}
interface ReportThresholds {
  /** 分类达标线 */
  accuracy?: number;
  macroF1?: number;
  /** 回归：MAE / 基线的上限 */
  maeRatio?: number;
}
interface ReportInput {
  title: string;
  /** 学生身份（姓名 / 学号）—— 来自平台 `GET /me`，写进报告头部。 */
  student?: {
    name?: string;
    studentId?: string;
  };
  kind: ExperimentKind;
  cases: ReportCase[];
  /** 踩坑记录（每条一行；来自过程记录或模型在 finalize 时补） */
  pitfalls: string[];
  /** 结论；缺省时回落到最后一个 case 的 notes */
  conclusion?: string;
  thresholds?: ReportThresholds;
  /** 生成时间（ISO）；缺省用当前时间 */
  generatedAt?: string;
  /** 自测方式：本地 DSH 或平台工作台 */
  mode?: string;
  /** 基线做法的一句话说明（模型可从题目包读出后传入） */
  baselineNote?: string;
}
/** 渲染 `report.md`。返回的文本只含确定信息：读不到的字段写 `—`，不猜。 */
declare function renderReport(input: ReportInput): string;
/** 报告是否"齐全"（与平台判据同口径：自测时间 + case 行有数字 + 踩坑 ≥1）。 */
declare function reportLooksComplete(markdown: string): boolean;
/** 报告里还缺什么（给模型/学生看的提示）。 */
declare function missingReportParts(markdown: string): string[];

//#endregion
//#region src/host/index.d.ts
declare const name = "nju-lab-client";
/**
 * 只硬依赖 `tools`（注册平台工具）。
 *
 * **不能**把 `connection` / `settings` 写进 inject：headless profile 两者都没有，
 * 硬依赖会让插件在 headless 下整个不加载（cordis 的 `cannot get property … without
 * inject` 是访问即抛错，不能靠运行时探测绕过）。这类"有就增强"的服务一律用
 * `ctx.inject([...], cb)`。
 */
declare const inject: string[];
/**
 * host 半入口：平台 API + 评估条件锁定 + 平台工具（+ 有 web server 时的面板路由）。
 *
 * 配置有两个来源，用户设置层优先于 `cordis.patch.yml` 的 composition 层：
 *  1. composition：profile 的 patch（从 `NJU_LAB_SERVER_URL` / `NJU_LAB_TOKEN` 取）
 *  2. 用户设置：DSH 设置页里本插件的条目（profile 条目 id = `nju-lab-client`）
 *
 * DSH 0.1.7 起设置节不再由插件手动注册：DSH 按 profile 条目 id 自动投影 Config 里
 * 标了 `.volatile()` 的字段（见 `config.ts`），用户改动即时写回 volatile 引用。
 *
 * client 半（UI）在 src/client/index.tsx，由 client-modules 服务按
 * package.json 的 dsh.client 声明单独扫描挂载。
 */
declare function apply(ctx: Context, config: Config): void;

//#endregion
export { Config, advanceStep, apply, describeStep, detectKind, guidePath, inject, kindFromDeclaration, loadGuide, missingReportParts, name, newGuideState, rebaseKind, recordStep, renderReport, renderStepList, reportLooksComplete, saveGuide, stepList, stepsFor, upgradeKind };