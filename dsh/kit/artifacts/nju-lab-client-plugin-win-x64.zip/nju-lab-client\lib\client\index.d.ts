import { Context } from "@deepseek-ai/cordis";

//#region src/client/index.d.ts
declare const name = "nju-lab-client/client";
/**
 * 依赖的浏览器服务：
 *  - `slots`：注册 tab 内容（由 ui-renderer 提供）
 *  - `sidebarRightTabs`：注册 tab 类型（tab 两阶段注册的 stage one）
 *  - `sidebarRight`：导航控制器，自动打开本插件的 tab
 *  - `configForms`：设置卡片的命名空间读写（由 ui-settings 提供）
 *  - `sessions`：读当前选中会话 id（面板把它带给 host，让材料落到会话工作区）
 */
declare const inject: string[];
declare function apply(ctx: Context): void;

//#endregion
export { apply, inject, name };